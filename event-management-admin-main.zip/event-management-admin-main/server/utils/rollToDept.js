module.exports = rollToDept = {
  '1': 'COMPS',
  '2': 'MECH',
  '3': 'EXTC',
  '4': 'ELEC',
  '5': 'IT',
  '9': 'OTHER',
};
