export const API_URI =
  process.env.REACT_APP_SERVER_URL || 'http://localhost:4000/';
